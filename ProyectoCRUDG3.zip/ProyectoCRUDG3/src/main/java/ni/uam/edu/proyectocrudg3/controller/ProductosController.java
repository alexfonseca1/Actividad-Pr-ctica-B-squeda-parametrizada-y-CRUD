package ni.uam.edu.proyectocrudg3.controller;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import ni.uam.edu.proyectocrudg3.database.ConexionBD;
import ni.uam.edu.proyectocrudg3.model.Categoria;
import ni.uam.edu.proyectocrudg3.model.Marca;
import ni.uam.edu.proyectocrudg3.model.Producto;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ProductosController {

    // ================= FORMULARIO =================

    @FXML private TextField txtCodigo;
    @FXML private TextField txtNombre;
    @FXML private TextField txtDescripcion;
    @FXML private TextField txtPrecio;
    @FXML private TextField txtStock;

    @FXML private ComboBox<Categoria> cmbCategoria;
    @FXML private ComboBox<Marca> cmbMarca;
    @FXML private DatePicker dpFecha;

    @FXML private Button btnNuevo;
    @FXML private Button btnGuardar;
    @FXML private Button btnActualizar;
    @FXML private Button btnEliminar;

    // ================= FILTROS =================

    @FXML private TextField txtBusqueda;
    @FXML private TextField txtPrecioMinimo;
    @FXML private TextField txtPrecioMaximo;

    @FXML private ComboBox<Categoria> cmbFiltroCategoria;
    @FXML private ComboBox<String> cmbOrdenarPor;

    @FXML private DatePicker dpDesde;
    @FXML private DatePicker dpHasta;
    @FXML private RadioButton rbSoloExistencia;

    @FXML private Button btnBuscar;
    @FXML private Button btnLimpiarFiltros;

    // ================= TABLA =================

    @FXML private TableView<Producto> tblProductos;

    @FXML private TableColumn<Producto, String> colCodigo;
    @FXML private TableColumn<Producto, String> colNombre;
    @FXML private TableColumn<Producto, String> colCategoria;
    @FXML private TableColumn<Producto, String> colMarca;
    @FXML private TableColumn<Producto, Double> colPrecio;
    @FXML private TableColumn<Producto, Integer> colStock;
    @FXML private TableColumn<Producto, LocalDate> colFechaCreacion;

    // ================= LISTAS =================

    private final ObservableList<Producto> listaProductos =
            FXCollections.observableArrayList();

    private final ObservableList<Categoria> listaCategorias =
            FXCollections.observableArrayList();

    private final ObservableList<Marca> listaMarcas =
            FXCollections.observableArrayList();

    private Producto productoSeleccionado;

    // ================= INICIALIZACIÓN =================

    @FXML
    private void initialize() {
        configurarTableView();
        configurarSeleccionTableView();
        cargarOpcionesOrden();

        btnNuevo.setOnAction(event -> nuevo());
        btnGuardar.setOnAction(event -> guardar());
        btnActualizar.setOnAction(event -> actualizar());
        btnEliminar.setOnAction(event -> eliminar());
        btnBuscar.setOnAction(event -> buscar());
        btnLimpiarFiltros.setOnAction(event -> limpiarFiltros());

        limpiarFormulario();
        cargarCategorias();
        cargarMarcas();
        cargarProductos();
    }

    // ================= CONFIGURACIÓN DE TABLA =================

    private void configurarTableView() {
        colCodigo.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getCodigo())
        );

        colNombre.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getNombre())
        );

        colCategoria.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getCategoria())
        );

        colMarca.setCellValueFactory(data ->
                new SimpleStringProperty(data.getValue().getMarca())
        );

        colPrecio.setCellValueFactory(data ->
                new SimpleDoubleProperty(
                        data.getValue().getPrecio()
                ).asObject()
        );

        colStock.setCellValueFactory(data ->
                new SimpleIntegerProperty(
                        data.getValue().getStock()
                ).asObject()
        );

        colFechaCreacion.setCellValueFactory(data ->
                new SimpleObjectProperty<>(
                        data.getValue().getFechaCreacion()
                )
        );

        tblProductos.setItems(listaProductos);
        tblProductos.setPlaceholder(
                new Label("No hay productos para mostrar.")
        );
    }

    private void configurarSeleccionTableView() {
        tblProductos.getSelectionModel()
                .selectedItemProperty()
                .addListener((observable, oldValue, newValue) -> {
                    if (newValue != null) {
                        cargarProductoEnFormulario(newValue);
                    } else {
                        limpiarFormulario();
                    }
                });
    }

    private void cargarProductoEnFormulario(Producto p) {
        productoSeleccionado = p;

        txtCodigo.setText(p.getCodigo());
        txtNombre.setText(p.getNombre());
        txtDescripcion.setText(p.getDescripcion());
        txtPrecio.setText(String.valueOf(p.getPrecio()));
        txtStock.setText(String.valueOf(p.getStock()));
        dpFecha.setValue(p.getFechaCreacion());

        cmbCategoria.setValue(null);
        cmbMarca.setValue(null);

        for (Categoria categoria : listaCategorias) {
            if (categoria.getIdCategoria() == p.getIdCategoria()) {
                cmbCategoria.setValue(categoria);
                break;
            }
        }

        for (Marca marca : listaMarcas) {
            if (marca.getIdMarca() == p.getIdMarca()) {
                cmbMarca.setValue(marca);
                break;
            }
        }

        btnGuardar.setDisable(true);
        btnActualizar.setDisable(false);
        btnEliminar.setDisable(false);
    }

    // ================= CATEGORÍAS Y MARCAS =================

    private void cargarCategorias() {
        listaCategorias.clear();

        String sql = """
                SELECT id_categoria, nombre
                FROM catalogos.categorias
                WHERE estado = 1
                ORDER BY nombre
                """;

        try (
                Connection conexion = ConexionBD.getConnection();
                PreparedStatement ps = conexion.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                listaCategorias.add(new Categoria(
                        rs.getInt("id_categoria"),
                        rs.getString("nombre")
                ));
            }

            cmbCategoria.setItems(
                    FXCollections.observableArrayList(listaCategorias)
            );

            cmbFiltroCategoria.setItems(
                    FXCollections.observableArrayList(listaCategorias)
            );

            cmbFiltroCategoria.setPromptText("Todas");

        } catch (SQLException e) {
            mostrarErrorBaseDatos(
                    "No se pudieron cargar las categorías.", e
            );
        }
    }

    private void cargarMarcas() {
        listaMarcas.clear();

        String sql = """
                SELECT id_marca, nombre
                FROM catalogos.marcas
                WHERE estado = 1
                ORDER BY nombre
                """;

        try (
                Connection conexion = ConexionBD.getConnection();
                PreparedStatement ps = conexion.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                listaMarcas.add(new Marca(
                        rs.getInt("id_marca"),
                        rs.getString("nombre")
                ));
            }

            cmbMarca.setItems(
                    FXCollections.observableArrayList(listaMarcas)
            );

        } catch (SQLException e) {
            mostrarErrorBaseDatos(
                    "No se pudieron cargar las marcas.", e
            );
        }
    }

    private void cargarOpcionesOrden() {
        cmbOrdenarPor.setItems(
                FXCollections.observableArrayList(
                        "Nombre",
                        "Precio menor a mayor",
                        "Precio mayor a menor",
                        "Fecha más reciente",
                        "Fecha más antigua",
                        "Stock mayor a menor",
                        "Stock menor a mayor"
                )
        );

        cmbOrdenarPor.setValue("Nombre");
    }

    private Producto crearProductoDesdeResultSet(
            ResultSet rs
    ) throws SQLException {
        java.sql.Date fecha = rs.getDate("fecha_creacion");

        return new Producto(
                rs.getInt("id_producto"),
                rs.getString("codigo"),
                rs.getString("nombre"),
                rs.getString("descripcion"),
                rs.getDouble("precio"),
                rs.getInt("stock"),
                fecha == null ? null : fecha.toLocalDate(),
                rs.getInt("id_categoria"),
                rs.getString("categoria"),
                rs.getInt("id_marca"),
                rs.getString("marca"),
                rs.getInt("estado")
        );
    }

    // ================= CARGA Y BÚSQUEDA =================

    private boolean cargarProductos() {
        StringBuilder sql = new StringBuilder("""
                SELECT
                    p.id_producto,
                    p.codigo,
                    p.nombre,
                    p.descripcion,
                    p.precio,
                    p.stock,
                    p.fecha_creacion,
                    p.id_categoria,
                    c.nombre AS categoria,
                    p.id_marca,
                    m.nombre AS marca,
                    p.estado
                FROM catalogos.productos p
                INNER JOIN catalogos.categorias c
                    ON p.id_categoria = c.id_categoria
                INNER JOIN catalogos.marcas m
                    ON p.id_marca = m.id_marca
                WHERE p.estado = 1
                """);

        List<Object> parametros = new ArrayList<>();

        try {
            String texto = txtBusqueda.getText().trim();

            if (!texto.isBlank()) {
                sql.append("""
                         AND (
                             p.codigo ILIKE ?
                             OR p.nombre ILIKE ?
                         )
                        """);

                parametros.add("%" + texto + "%");
                parametros.add("%" + texto + "%");
            }

            Categoria categoria = cmbFiltroCategoria.getValue();

            if (categoria != null) {
                sql.append(" AND p.id_categoria = ?");
                parametros.add(categoria.getIdCategoria());
            }

            LocalDate desde = dpDesde.getValue();
            LocalDate hasta = dpHasta.getValue();

            if (desde != null && hasta != null
                    && desde.isAfter(hasta)) {
                throw new IllegalArgumentException(
                        "La fecha inicial no puede ser posterior a la fecha final."
                );
            }

            if (desde != null) {
                sql.append(" AND p.fecha_creacion >= ?");
                parametros.add(desde);
            }

            if (hasta != null) {
                sql.append(" AND p.fecha_creacion <= ?");
                parametros.add(hasta);
            }

            BigDecimal minimo = leerPrecioFiltro(
                    txtPrecioMinimo, "El precio mínimo"
            );

            BigDecimal maximo = leerPrecioFiltro(
                    txtPrecioMaximo, "El precio máximo"
            );

            if (minimo != null && maximo != null
                    && minimo.compareTo(maximo) > 0) {
                throw new IllegalArgumentException(
                        "El precio mínimo no puede ser mayor que el precio máximo."
                );
            }

            if (minimo != null) {
                sql.append(" AND p.precio >= ?");
                parametros.add(minimo);
            }

            if (maximo != null) {
                sql.append(" AND p.precio <= ?");
                parametros.add(maximo);
            }

            if (rbSoloExistencia.isSelected()) {
                sql.append(" AND p.stock > 0");
            }

            sql.append(" ORDER BY ").append(obtenerOrdenSQL());

            ObservableList<Producto> resultados =
                    FXCollections.observableArrayList();

            try (
                    Connection conexion = ConexionBD.getConnection();
                    PreparedStatement ps =
                            conexion.prepareStatement(sql.toString())
            ) {
                for (int i = 0; i < parametros.size(); i++) {
                    Object valor = parametros.get(i);

                    if (valor instanceof LocalDate fecha) {
                        ps.setDate(
                                i + 1,
                                java.sql.Date.valueOf(fecha)
                        );

                    } else if (valor instanceof BigDecimal numero) {
                        ps.setBigDecimal(i + 1, numero);

                    } else {
                        ps.setObject(i + 1, valor);
                    }
                }

                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        resultados.add(
                                crearProductoDesdeResultSet(rs)
                        );
                    }
                }
            }

            // Actualiza la tabla solo si la consulta fue correcta.
            tblProductos.getSelectionModel().clearSelection();
            limpiarFormulario();

            tblProductos.getSortOrder().clear();
            listaProductos.setAll(resultados);

            return true;

        } catch (IllegalArgumentException e) {
            mostrarAdvertencia(e.getMessage());
            return false;

        } catch (SQLException e) {
            mostrarErrorBaseDatos(
                    "No se pudo realizar la búsqueda.", e
            );
            return false;
        }
    }

    private String obtenerOrdenSQL() {
        String opcion = cmbOrdenarPor.getValue();

        if (opcion == null) {
            return "p.nombre ASC";
        }

        // Solo utiliza columnas conocidas.
        return switch (opcion) {
            case "Precio menor a mayor" -> "p.precio ASC";
            case "Precio mayor a menor" -> "p.precio DESC";
            case "Fecha más reciente" -> "p.fecha_creacion DESC";
            case "Fecha más antigua" -> "p.fecha_creacion ASC";
            case "Stock mayor a menor" -> "p.stock DESC";
            case "Stock menor a mayor" -> "p.stock ASC";
            default -> "p.nombre ASC";
        };
    }

    private BigDecimal leerPrecioFiltro(
            TextField campo,
            String nombre
    ) {
        if (campo.getText().isBlank()) {
            return null;
        }

        BigDecimal valor;

        try {
            valor = new BigDecimal(
                    campo.getText().trim().replace(',', '.')
            );

        } catch (NumberFormatException e) {
            campo.requestFocus();

            throw new IllegalArgumentException(
                    nombre + " debe ser un número válido."
            );
        }

        if (valor.compareTo(BigDecimal.ZERO) < 0) {
            campo.requestFocus();

            throw new IllegalArgumentException(
                    nombre + " no puede ser negativo."
            );
        }

        return valor;
    }

    @FXML
    private void buscar() {
        boolean consultaCorrecta = cargarProductos();

        if (consultaCorrecta && listaProductos.isEmpty()) {
            mostrarInformacion(
                    "No existen productos que coincidan "
                            + "con los filtros aplicados."
            );
        }
    }

    @FXML
    private void limpiarFiltros() {
        txtBusqueda.clear();
        txtPrecioMinimo.clear();
        txtPrecioMaximo.clear();

        dpDesde.setValue(null);
        dpHasta.setValue(null);

        cmbFiltroCategoria.setValue(null);
        cmbOrdenarPor.setValue("Nombre");
        rbSoloExistencia.setSelected(false);

        cargarProductos();
    }

    // ================= NUEVO Y LIMPIEZA =================

    @FXML
    private void nuevo() {
        tblProductos.getSelectionModel().clearSelection();
        limpiarFormulario();
        txtCodigo.requestFocus();
    }

    private void limpiarFormulario() {
        productoSeleccionado = null;

        txtCodigo.clear();
        txtNombre.clear();
        txtDescripcion.clear();
        txtPrecio.clear();
        txtStock.clear();

        cmbCategoria.setValue(null);
        cmbMarca.setValue(null);
        dpFecha.setValue(LocalDate.now());

        btnGuardar.setDisable(false);
        btnActualizar.setDisable(true);
        btnEliminar.setDisable(true);
    }

    // ================= VALIDACIONES =================

    private Producto leerFormulario() {
        String codigo = txtCodigo.getText().trim();
        String nombre = txtNombre.getText().trim();

        if (codigo.isEmpty()) {
            throw new IllegalArgumentException(
                    "Ingresá el código del producto."
            );
        }

        if (nombre.isEmpty()) {
            throw new IllegalArgumentException(
                    "Ingresá el nombre del producto."
            );
        }

        if (cmbCategoria.getValue() == null) {
            throw new IllegalArgumentException(
                    "Seleccioná una categoría."
            );
        }

        if (cmbMarca.getValue() == null) {
            throw new IllegalArgumentException(
                    "Seleccioná una marca."
            );
        }

        if (dpFecha.getValue() == null) {
            throw new IllegalArgumentException(
                    "Seleccioná una fecha válida."
            );
        }

        double precio = leerNumeroDecimal(
                txtPrecio.getText(), "El precio"
        );

        if (precio <= 0) {
            throw new IllegalArgumentException(
                    "El precio debe ser mayor que cero."
            );
        }

        int stock;

        try {
            stock = Integer.parseInt(txtStock.getText().trim());

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                    "El stock debe ser un número entero."
            );
        }

        if (stock < 0) {
            throw new IllegalArgumentException(
                    "El stock no puede ser negativo."
            );
        }

        Categoria categoria = cmbCategoria.getValue();
        Marca marca = cmbMarca.getValue();

        return new Producto(
                productoSeleccionado == null
                        ? 0 : productoSeleccionado.getIdProducto(),
                codigo,
                nombre,
                txtDescripcion.getText().trim(),
                precio,
                stock,
                dpFecha.getValue(),
                categoria.getIdCategoria(),
                categoria.getNombre(),
                marca.getIdMarca(),
                marca.getNombre(),
                1
        );
    }

    private double leerNumeroDecimal(String texto, String nombre) {
        try {
            double valor = Double.parseDouble(
                    texto.trim().replace(',', '.')
            );

            if (!Double.isFinite(valor)) {
                throw new NumberFormatException();
            }

            return valor;

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(
                    nombre + " debe ser un número válido."
            );
        }
    }

    // ================= CÓDIGO DUPLICADO =================

    private boolean existeCodigo(
            String codigo,
            Integer idProductoExcluir
    ) throws SQLException {
        /*
         * Incluye productos desactivados porque
         * sus códigos siguen registrados.
         */
        String sql = """
                SELECT 1
                FROM catalogos.productos
                WHERE codigo = ?
                """;

        if (idProductoExcluir != null) {
            sql += " AND id_producto <> ?";
        }

        try (
                Connection conexion = ConexionBD.getConnection();
                PreparedStatement ps = conexion.prepareStatement(sql)
        ) {
            ps.setString(1, codigo);

            if (idProductoExcluir != null) {
                ps.setInt(2, idProductoExcluir);
            }

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    // ================= GUARDAR Y ACTUALIZAR =================

    @FXML
    private void guardar() {
        guardarOActualizar(false);
    }

    @FXML
    private void actualizar() {
        if (productoSeleccionado == null) {
            mostrarAdvertencia(
                    "Seleccioná un producto para actualizar."
            );
            return;
        }

        guardarOActualizar(true);
    }

    private void guardarOActualizar(boolean actualizar) {
        try {
            if (actualizar && productoSeleccionado == null) {
                mostrarAdvertencia(
                        "Seleccioná un producto para actualizar."
                );
                return;
            }

            Producto p = leerFormulario();

            // Lee el texto directamente para enviarlo como BigDecimal.
            BigDecimal precio;

            try {
                precio = new BigDecimal(
                        txtPrecio.getText().trim().replace(',', '.')
                );

            } catch (NumberFormatException e) {
                throw new IllegalArgumentException(
                        "El precio debe ser un número decimal válido."
                );
            }

            Integer idExcluir = actualizar
                    ? p.getIdProducto()
                    : null;

            if (existeCodigo(p.getCodigo(), idExcluir)) {
                mostrarAdvertencia(
                        "El código " + p.getCodigo()
                                + " ya pertenece a otro producto."
                );

                txtCodigo.requestFocus();
                return;
            }

            String sql;

            if (actualizar) {
                sql = """
                        UPDATE catalogos.productos
                        SET codigo = ?,
                            nombre = ?,
                            descripcion = ?,
                            precio = ?,
                            stock = ?,
                            fecha_creacion = ?,
                            id_categoria = ?,
                            id_marca = ?
                        WHERE id_producto = ?
                          AND estado = 1
                        """;

            } else {
                sql = """
                        INSERT INTO catalogos.productos (
                            codigo,
                            nombre,
                            descripcion,
                            precio,
                            stock,
                            fecha_creacion,
                            id_categoria,
                            id_marca,
                            estado
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
                        """;
            }

            try (
                    Connection conexion = ConexionBD.getConnection();
                    PreparedStatement ps = conexion.prepareStatement(sql)
            ) {
                ps.setString(1, p.getCodigo());
                ps.setString(2, p.getNombre());
                ps.setString(3, p.getDescripcion());
                ps.setBigDecimal(4, precio);
                ps.setInt(5, p.getStock());

                ps.setDate(
                        6,
                        java.sql.Date.valueOf(p.getFechaCreacion())
                );

                ps.setInt(7, p.getIdCategoria());
                ps.setInt(8, p.getIdMarca());

                if (actualizar) {
                    ps.setInt(9, p.getIdProducto());
                }

                int filasAfectadas = ps.executeUpdate();

                if (filasAfectadas == 0) {
                    mostrarAdvertencia(
                            "No se realizó la operación. "
                                    + "El producto podría haber sido "
                                    + "desactivado o eliminado."
                    );
                    return;
                }
            }

            nuevo();
            cargarProductos();

            mostrarInformacion(
                    actualizar
                            ? "Producto actualizado correctamente."
                            : "Producto guardado correctamente."
            );

        } catch (IllegalArgumentException e) {
            mostrarAdvertencia(e.getMessage());

        } catch (SQLException e) {
            // PostgreSQL realiza la comprobación final de UNIQUE.
            if ("23505".equals(e.getSQLState())) {
                mostrarAdvertencia(
                        "Ya existe un producto con ese código o nombre."
                );

            } else {
                mostrarErrorBaseDatos(
                        actualizar
                                ? "No se pudo actualizar el producto."
                                : "No se pudo guardar el producto.",
                        e
                );
            }
        }
    }

    // ================= ELIMINAR =================

    @FXML
    private void eliminar() {
        if (productoSeleccionado == null) {
            mostrarAdvertencia(
                    "Seleccioná un producto para eliminar."
            );
            return;
        }

        Alert confirmacion = new Alert(Alert.AlertType.CONFIRMATION);
        confirmacion.setTitle("Eliminar producto");
        confirmacion.setHeaderText(null);
        confirmacion.setContentText(
                "¿Querés desactivar el producto \""
                        + productoSeleccionado.getNombre() + "\"?"
        );

        boolean confirmado = confirmacion.showAndWait()
                .filter(respuesta -> respuesta == ButtonType.OK)
                .isPresent();

        if (!confirmado) {
            return;
        }

        // Eliminación lógica: conserva el registro.
        String sql = """
                UPDATE catalogos.productos
                SET estado = 0
                WHERE id_producto = ?
                  AND estado = 1
                """;

        try (
                Connection conexion = ConexionBD.getConnection();
                PreparedStatement ps = conexion.prepareStatement(sql)
        ) {
            ps.setInt(1, productoSeleccionado.getIdProducto());

            if (ps.executeUpdate() == 0) {
                mostrarAdvertencia(
                        "El producto ya no está activo."
                );
                return;
            }

            nuevo();
            cargarProductos();

            mostrarInformacion(
                    "Producto desactivado correctamente."
            );

        } catch (SQLException e) {
            mostrarErrorBaseDatos(
                    "No se pudo eliminar el producto.", e
            );
        }
    }

    // ================= MENSAJES =================

    private void mostrarErrorBaseDatos(
            String mensaje,
            SQLException e
    ) {
        String detalle;

        if ("23505".equals(e.getSQLState())) {
            detalle = "Ya existe un producto con ese código o nombre.";
        } else {
            detalle = e.getMessage();
        }

        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error de base de datos");
        alerta.setHeaderText(mensaje);
        alerta.setContentText(detalle);
        alerta.showAndWait();
    }

    private void mostrarAdvertencia(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.WARNING);
        alerta.setTitle("Validación");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    private void mostrarInformacion(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setTitle("Gestión de productos");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}