package ni.uam.edu.proyectocrudg3;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(ProductosApplication.class, args);
    }
}
