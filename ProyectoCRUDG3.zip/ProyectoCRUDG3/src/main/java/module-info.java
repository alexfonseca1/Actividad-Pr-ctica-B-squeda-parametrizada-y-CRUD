module ni.uam.edu.proyectocrudg3 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens ni.uam.edu.proyectocrudg3 to javafx.fxml;
    exports ni.uam.edu.proyectocrudg3;
    opens ni.uam.edu.proyectocrudg3.controller to javafx.fxml;
}